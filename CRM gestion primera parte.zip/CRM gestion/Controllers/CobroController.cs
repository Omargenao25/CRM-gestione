﻿using CRM_gestion.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRM_gestion.Controllers
{
    public class CobroController : Controller
    {
        private static List<Cobro> _cobros = new List<Cobro>();

        public IActionResult Index()
        {
            return View(_cobros);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Cobro cobro)
        {
            if (ModelState.IsValid)
            {
                cobro.Id = _cobros.Any() ? _cobros.Max(c => c.Id) + 1 : 1;
                _cobros.Add(cobro);
                return RedirectToAction("Index");
            }
            return View(cobro);
        }

        public IActionResult Details(int id)
        {
            var cobro = _cobros.FirstOrDefault(c => c.Id == id);
            if (cobro == null)
                return NotFound();

            return View(cobro);
        }
    }
}

