﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CRM_gestion.Models
{
    public class Cobro
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "El ClienteId es obligatorio.")]
        public int ClienteId { get; set; } 

        [Required(ErrorMessage = "El DeudaId es obligatorio.")]
        public int DeudaId { get; set; } 

        [Required(ErrorMessage = "El monto cobrado es obligatorio.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El monto cobrado debe ser mayor a 0.")]
        public decimal MontoCobrado { get; set; }

        [Required(ErrorMessage = "La fecha de cobro es obligatoria.")]
        public DateTime FechaCobro { get; set; }

        [StringLength(500, ErrorMessage = "Las observaciones no pueden exceder los 500 caracteres.")]
        public required string Observaciones { get; set; }
    }
}
