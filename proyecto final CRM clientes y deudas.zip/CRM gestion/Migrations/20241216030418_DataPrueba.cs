﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CRM_gestion.Migrations
{
    /// <inheritdoc />
    public partial class DataPrueba : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
